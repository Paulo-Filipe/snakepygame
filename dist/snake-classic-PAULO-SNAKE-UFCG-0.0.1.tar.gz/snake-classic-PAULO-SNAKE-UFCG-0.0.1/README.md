# Snake PyGame
implementing the classic game Snake on Python 3 (pygame) for fun.

``ReadMe still in development.`` as well is the game.


to run the game:

```
python snake.py
```

Controls:
- UP ARROW: change direction upwards.
- DOWN ARROW: change direction downwards.
- LEFT ARROW: change direction leftwards.
- RIGHT ARROW: change direction rightwards.